package com.anjali.xebia.Model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TimeToReadArticle {
    String articleId;
    TimeToRead timeToRead;
}


