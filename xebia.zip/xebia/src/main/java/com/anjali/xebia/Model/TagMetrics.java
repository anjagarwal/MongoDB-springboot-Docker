package com.anjali.xebia.Model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TagMetrics {
    String tag;
    String occurence;
}
